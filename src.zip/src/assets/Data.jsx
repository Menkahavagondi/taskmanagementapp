export const tasksList=[
    {
        title:"react",
        description:"this is react application",
        duedate:"2023-12-15",
        status:'completed',
        id:1
    },
    {
        title:"redux",
        description:"this is redux application",
        duedate:"2023-12-30",
        status:'pending',
        id:2
    },
    {
        title:"react-redux",
        description:"this is react-redux application",
        duedate:"2023-12-25",
        status:'in progress',
        id:3
    }
];

// {
//     "tasks":[
//         {
//             "title":"react",
//             "description":"this is react application",
//             "duedate":10,
//             "status":"completed"
//         },
//         {
//             "title":"redux",
//             "description":"this is redux application",
//             "duedate":15,
//             "status":"pending"
//         },
//         {
//             "title":"react-redux",
//             "description":"this is react-redux application",
//             "duedate":13,
//             "status":"in progress"
//         } 
//     ]
//  }